{"main":
 {"style": "background-image:url($path/tnbg2.png);background-color:rgba(0,0,0,0); background-repeat: no-repeat;",
  "size": [650, 450],
  "icon": "$path/trayicon.png",
  "newmsgicon": "$path/trayicon2.png",
  "windowtitle": "TROLLIAN",
  "close": { "image": "$path/x.gif",
             "loc": [635, 2]},
  "minimize": { "image": "$path/m.gif",
                "loc": [618, 4]},
  "menubar": { "style": "font-family: 'Arial'; font-size: 11px; color: rgba(0,0,0,0);" },
  "menu" : { "style": "font-family: 'Arial'; font-size: 11px; background-color: #c2c2c2; border:1px solid #545454;",
             "selected": "background-color: #545454",
             "menuitem": "margin-right:14px;",
             "loc": [14,90]
           },
  "sounds": { "alertsound": "$path/alarm.wav" },
  "menus": {"client": {"_name": "Trollian",
                       "options": "Options",
                       "memos": "Memos",
                       "userlist": "Fresh Targets",
                       "exit": "Abscond"},
            "profile": {"_name": "View",
                        "switch": "Trolltag",
                        "theme": "Theme",
                        "color": "Hemospectrum",
                        "block": "Chumpdump",
                        "quirks": "Annoying"},
            "rclickchumlist": {"pester": "Troll",
                               "removechum": "Trash",
                               "blockchum": "Block",
                               "addchum": "Add Chump",
                               "unblockchum": "Mercy"}
           },
  "chums": { "style": "font-size: 12px; background: white; border:2px solid #c2c2c2; padding: 5px; font-family: 'Arial';selection-background-color:rgb(200,200,200); ",
             "loc": [475, 89],
             "size": [175, 361],
             "userlistcolor": "black",
             "moods": {
                 
                 "chummy": { "icon": "$path/chummy.png", "color": "#63ea00" },
                 
                 "rancorous": { "icon": "$path/rancorous.png", "color": "#7f7f7f" },
                 
                 "offline": { "icon": "$path/offline.png", "color": "black"},
                 
                 
                 "pleasant": { "icon": "$path/pleasant.png", "color": "#d69df8" },
                 
                 "distraught": { "icon": "$path/distraught.png", "color": "#706eba" },
                 
                 "unruly": { "icon": "$path/unruly.png", "color": "blue" },
                 
                 
                 "smooth": { "icon": "$path/smooth.png", "color": "red" },
                 
                 
                 "ecstatic": { "icon": "$path/ecstatic.png", "color": "#99004d" },
                 
                 "relaxed": { "icon": "$path/relaxed.png", "color": "#078446" },
                 
                 "discontent": { "icon": "$path/discontent.png", "color": "#a75403" },
                 
                 "devious": { "icon": "$path/devious.png", "color": "#008282" },
                 
                 "sleek": { "icon": "$path/sleek.png", "color": "#a1a100" },
                 
                 "detestful": { "icon": "$path/detestful.png", "color": "#6a006a" },
                 
                 "mirthful": { "icon": "$path/mirthful.png", "color": "#450077" },
                 
                 "manipulative": { "icon": "$path/manipulative.png", "color": "#004182" },
                 
                 "vigorous": { "icon": "$path/vigorous.png", "color": "#0021cb" },
                 
                 "perky": { "icon": "$path/perky.png", "color": "#406600" },
                 
                 "acceptant": { "icon": "$path/acceptant.png", "color": "#a10000" },
                 
                 "protective": { "icon": "$path/protective.png", "color": "white" },
                 
                 "blocked": { "icon": "$path/blocked.png", "color": "black" }
                 
             }
           },
  "trollslum": {
      "style": "background:  rgb(190, 19, 4); font-family: 'Arial'",
      "size": [175, 461],
      "label": { "text": "Chumpdump",
                 "style": "color: rgba(0, 0, 0, 100%) ;font:bold; font-family: 'Arial';border: 0px;" },
      "chumroll": {"style": "border: 0px; background-color: white; padding: 5px; font-family: 'Arial';selection-background-color:rgb(200,200,200); " }
  },
  "mychumhandle": { "label": { "text": "",
                               "loc": [0,0],
                               "style": "color:rgba(0,0,0,0);" },
                    "handle": { "style": "background: rgba(0,0,0,0); color:rgba(0,0,0,0);",
                                "loc": [0,0],
                                "size": [0,0] },
                    "colorswatch": { "loc": [0,0],
                                     "size": [0,0],
                                     "text": "" }
                  },
  "defaultwindow": { "style": "background: #c2c2c2; font-family:'Arial';font:bold;selection-background-color:#545454; "
                   },
  "addchum": { "style": "background: rgba(0,0,0,0); border:0px; color: rgba(0,0,0,0);",
               "loc": [475, 67],
               "size": [175, 18],
               "text": ""
             },
  "pester": { "style": "background: rgba(0,0,0,0); border:0px; color: rgba(0,0,0,0);",
              "loc": [0,0],
              "size": [0, 0],
              "text": ""
            },
  "block": { "style": "background: rgba(0,0,0,0); border:0px; color: rgba(0,0,0,0);",
             "loc": [1500,202],
             "size": [71, 22],
             "text": ""
           },
  "defaultmood": 7,
  "moodlabel": { "style": "",
                 "loc": [0, 0],
                 "text": ""
               },
  "moods": [
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck1.png); border:0px;",
        "loc": [25, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 17
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck2.png); border:0px;",
        "loc": [60, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 9
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck3.png); border:0px;",
        "loc": [95, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 11
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck4.png); border:0px;",
        "loc": [130, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 1
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck5.png); border:0px;",
        "loc": [165, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 16
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck6.png); border:0px;",
        "loc": [200, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 8
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck7.png); border:0px;",
        "loc": [235, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 10
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck8.png); border:0px;",
        "loc": [270, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 14
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck9.png); border:0px;",
        "loc": [305, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 15
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck10.png); border:0px;",
        "loc": [340, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 13
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck11.png); border:0px;",
        "loc": [375, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 12
      },
      { "style": "border:0px;",
        "selected": "background-image:url($path/moodcheck12.png); border:0px;",
        "loc": [410, 141],
        "size": [20, 270],
        "text": "",
        "icon": "",
        "mood": 7
      },
      
      { "style": "border:0px;color: rgba(0, 0, 0, 0%);",
        "selected": "border:0px; color: rgba(0, 0, 0, 0%);",
        "loc": [12, 117],
        "size": [435, 18],
        "text": "",
        "icon": "",
        "mood": 2
      }
  ]
 },
 "convo":
 {"style": "background:  rgb(190, 19, 4); font-family: 'Arial';",
  "margins": {"top": 22, "bottom": 9, "left": 10, "right": 4 },
  "size": [400, 250],
  "chumlabel": { "style": "background: rgb(255, 38, 18); color: white; padding: 2px; border:1px solid #c2c2c2;",
                 "align": { "h": "left", "v": "center" },
                 "minheight": 18,
                 "maxheight": 18,
                 "text" : "trolling: $handle"
               },
  "textarea": {
      "style": "background: white; border:2px solid #c2c2c2; font-size: 12px; margin-top: 4px;"
  },
  "input": {
      "style": "background: white;margin-top:5px; border:1px solid #c2c2c2; margin-right: 54px; font-size: 12px; height: 19px;"
  },
  "tabs": {
      "style": "",
      "selectedstyle": "",
      "newmsgcolor": "red",
      "tabstyle": 0
  },
  "text": {
      "beganpester": "began trolling",
      "ceasepester": "gave up trolling",
      "blocked": "blocked",
      "unblocked": "mercifully forgave",
      "openmemo": "opened memo on board",
      "joinmemo": "responded to memo",
      "closememo": "ceased responding to memo"
  },
  "systemMsgColor": "#646464"
 },
 "memos":
 {"memoicon": "$path/memo.png",
  "style": "background:  rgb(190, 19, 4); font-family: 'Arial';",
  "size": [450,300],
  "tabs": {
      "style": "",
      "selectedstyle": "",
      "newmsgcolor": "red",
      "tabstyle": 0
  },
  "label": { "text": "Bulletin Board: $channel",
             "style": "background-image:url($path/chumlabelbg.png);background-color:rgb(255,38,18); background-repeat: no-repeat; color: white; padding: 2px; border:1px solid #c2c2c2;",
             "align": { "h": "left", "v": "center" },
             "minheight": 18,
             "maxheight": 18
           },
  "textarea": {
      "style": "background: white; border:2px solid #c2c2c2; font-size: 12px; margin-top: 4px;"
  },
  "input": {
      "style": "background: white;margin-top:5px; border:1px solid #c2c2c2; font-size: 12px; height: 19px; margin-bottom: 5px; "
  },
  "margins": {"top": 22, "bottom": 10, "left": 9, "right": 4 },
  "userlist": { "width": 125,
                "style": "font-size: 12px; background: white; margin-top: 4px; margin-left: 5px; margin-bottom: 5px; border:2px solid #c2c2c2; padding: 5px; font-family: 'Arial';selection-background-color:rgb(200,200,200);"
              },
  "time": { "text": { "width": 75, 
                      "style": "color: black; font:bold;  border:1px solid #c2c2c2; background: white; height: 19px;" 
                    },
            "slider": { "style": " border:1px solid #c2c2c2;",
                        "groove": "border-image:url($path/timeslideraqua.png);",
                        "handle": "image:url($path/aquaicon.png);"
                      },
            "buttons": { "style": "border:1px solid #a68168; height: 17px; width: 50px; color: #cd8f9d; font-family: 'Arial'; background: rgb(190, 19, 4); margin-left: 2px;" }, 
            "arrows": { "left": "$path/leftarrow.png", 
                        "right": "$path/rightarrow.png",
                        "style": "width: 19px; height: 19px; border:0px; margin-left: 2px;"
                      }
          },
  "systemMsgColor": "#646464"
 }
}